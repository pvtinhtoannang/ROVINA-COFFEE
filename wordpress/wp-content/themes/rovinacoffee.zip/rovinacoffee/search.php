<?php
/**
 * StartPress Framework.
 *
 * The template for displaying search.
 *
 * User: nhutfs
 * Date: 31/10/2019
 *
 * @link https://startpress.net
 *
 * @package WordPress
 * @subpackage StartPress Framework
 * @since 2.0.2
 */

startpress_search();
