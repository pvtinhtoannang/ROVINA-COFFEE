<footer class="footer-wrapper">
    <div class="left-area">
        <ul>
            <li><a href="/mo-quan">Mở quán <i class="fa fa-chevron-right"></i></a></li>
            <li><span class="line"></span><a href="/san-pham"><span class="color">MUA MÁY PHA</span></a><span class="line">\</span></li>
            <li>Hotline <span class="num"><a href="tel:0946888179">0946888179</a></span></li>
        </ul>
    </div>
    <div class="right-area">
        <ul>
            <li><a href="">  <img src="<?= get_theme_file_uri('/assets/images/facebook-logo.png') ?>" alt=""></a></li>
            <li><a href="">  <img src="<?= get_theme_file_uri('/assets/images/youtube-logo.png') ?>" alt=""></a></li>
            <li><a href="">  <img src="<?= get_theme_file_uri('/assets/images/google-logo.png') ?>" alt=""></a></li>
        </ul>
    </div>
</footer>