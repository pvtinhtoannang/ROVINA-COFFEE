<section class="sec-3">
    <div class="cup">
        <img src="<?= get_theme_file_uri('/assets/images/Lycafe.png') ?>" alt="">
    </div>
    <div class="page-container">
        <div class="sec-3-content">
            <h2 class="title">MỖI THÀNH VIÊN ROVINA COFFEE</h2>
            <h3 class="sub-title color">LÀ MỘT NGƯỜI TIÊN PHONG</h3>
            <h2 class="title">Mỗi ngày</h2>
            <div class="number">1.677.849</div>
            <div class="text">Ly cà phê Rovina 100% nguyên chất được thưởng thức</div>
            <div class="number">89</div>
            <div class="text">Quán cà phê Rovina đang phục vụ</div>
            <div class="btn-wrapper">
                <a class="text-uppercase" href="">Tìm quán</a>
            </div>
        </div>
    </div>
</section>