</div><!-- #content -->
<?php get_template_part('templates/template-footer'); ?>
</div><!-- #page -->
<?php wp_footer(); ?>
</body>
</html>
