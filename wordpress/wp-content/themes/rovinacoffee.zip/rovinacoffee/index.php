<?php
get_header();
get_template_part('templates/template-section-1');
get_template_part('templates/template-section-2');
get_template_part('templates/template-section-3');
get_template_part('templates/template-section-4');
get_template_part('templates/template-section-5');
get_footer();
